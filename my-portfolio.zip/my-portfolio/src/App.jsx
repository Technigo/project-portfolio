import React from "react";
import { Introduction } from "./Components/Introduction/Introduction";

function App() {
  return (
    <div>
      <Introduction />
    </div>
  );
}

export default App;

