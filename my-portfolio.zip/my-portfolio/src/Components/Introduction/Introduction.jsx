import "./Introduction.css";

export const Introduction = () => {
    return (
        <div>
            <div className="introduction">
                <p className="sherry">Hi, I'm Sherry Isola-Gbenla</p>


            </div>









        </div>

















    );

};
